module.exports = {
  // среда тестирования - браузер
  verbose: true,
  testEnvironment: 'jest-environment-jsdom',
};
