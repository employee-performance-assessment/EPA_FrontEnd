import React from 'react';
// import { Route, Routes, useNavigate } from 'react-router-dom';
// import ProtectedRoute from '../ProtectedRoute/ProtectedRoute';
// import MainPage from '../MainPage/MainPage.jsx'
// import Auth from '../Auth/Auth.jsx'
// import Board from '../Board/Board.jsx'
import Header from '../Header/Header.jsx';
// import END_POINT_API from '../../constant/constantAPI.js';
// import {
// вопрос, как лучше, пропсами методы апи прокидывать, или где нужно в компонентах импортить?
//   getCardAPI,
//   // getUserInfoAPI,
//   // getUsersAPI,
//   // getFirmInfoAPI,
//   getMyInfo
// } from '../../utils/mainAPI.js';
function App() {
  //  const { main, auth, board, personalArea, adminPanel, anyPage } =
  //  END_POINT_API;

  return (
    <div className="page">
      <div className="page__content">
        <Header />
        {/* <Routes> */}
        {/* проверяем, если залогинин, прогоняем через ProtectedRoute */}
        {/* ,если нет, то открывается страница авторизации */}
        {/* <Route path={loggedIn ? main : auth} element={loggedIn ?
          <ProtectedRoute element={MainPage} isLoggedIn={loggedIn}
          personalInfo={getMyInfo()} /> : <Auth />} /> */}
        {/* канбан доска */}
        {/* <Route path={board} element={<ProtectedRoute element={Board}
        arrCards={getCardAPI()} />} /> */}
        {/* страница без роута */}
        {/* <Route path={anyPage} element={<NotFound />} />
        </Routes> */}
      </div>
    </div>
  );
}

export default App;
