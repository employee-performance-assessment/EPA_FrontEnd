import React from 'react';
import './MainPage.css';
import Preloader from '../Preloader/Preloader.jsx';
import ErrorSearch from '../ErrorSearch/ErrorSearch.jsx';

function MainPage({ personalInfo }) {
  return (
    <>
      <Header isLoggedIn={isLoggedIn} theme="black" />
      <main>
        {props.status ? (
          <PersonalArea personalInfo={personalInfo} />
        ) : (
          <AdminPanel personalInfo={personalInfo} />
        )}
      </main>
      <Footer />
    </>
  );
}

export default MainPage;
